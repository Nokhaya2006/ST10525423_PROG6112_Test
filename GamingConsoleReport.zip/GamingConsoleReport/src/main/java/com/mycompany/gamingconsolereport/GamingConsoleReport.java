/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.gamingconsolereport;

/**
 *
 * @author Student
 */

public class GamingConsoleReport {
    public static void main(String[] args) {
        String[] cities = {"Cape Town", "Port Elizabeth", "Pretoria"};
        int[][] consoleSales = {
            {1000, 2000, 3000},
            {2000, 3000, 4000},
            {1500, 1100, 1200}
        };
        
        int highestTotal = 0; // Fixed: Added semicolon here
        int highestCityIndex = 0;

        System.out.println("NUMBER 1 ELECTRONICS YEARLY SALES REPORT");
        System.out.println("---------------------------------------------------------------");
        System.out.printf("%-15s %-8s %-8s %-18s %-8s%n", "City", "PS5", "XBOX", "NINTENDO SWITCH", "Total");
        System.out.println("---------------------------------------------------------------");

        for (int i = 0; i < cities.length; i++) {
            int ps5 = consoleSales[i][0];
            int xbox = consoleSales[i][1];
            int nintendoSwitch = consoleSales[i][2];

            int total = ps5 + xbox + nintendoSwitch;

            System.out.printf("%-15s %-8d %-8d %-18d %-8d%n", 
                cities[i], ps5, xbox, nintendoSwitch, total);

            if (total > highestTotal) {
                highestTotal = total;
                highestCityIndex = i;
            }
        }

        System.out.println("---------------------------------------------------------------");
        System.out.println("City with the highest number of sales: " + cities[highestCityIndex]);
        System.out.println("Highest total number of sales: " + highestTotal);
    }
}