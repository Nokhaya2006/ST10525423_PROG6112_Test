/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject1;

/**
 *
 * @author Student
 */
import java.util.Scanner;
public class Main {
private static final String[] TYPES = {"PS5", "XBOX", "SWITCH"};
public static void main(String[] args) {
Scanner in = new Scanner(System.in);
int choice = readChoice(in);
System.out.print("Enter the store: ");
String store = in.nextLine().trim();
System.out.print("Enter the total sales of " + TYPES[choice - 1]
" consoles for " + store + ": ");
int sales = readSales(in);
Console console = createConsole(choice, store, sales);
console.printReport();
}
private static int readChoice(Scanner in) {
while (true) {
System.out.println("Select the console type");
for (int i = 0; i < TYPES.length; i++) {
System.out.println(" " + (i + 1) + ") " + TYPES[i]);
}
String line = in.nextLine().trim();
if (line.matches("[1-3]")) {
return Integer.parseInt(line);
}
System.out.println("Invalid choice. Enter 1, 2 or 3.
");
}
}
private static int readSales(Scanner in) {
while (true) {
String line = in.nextLine().trim();
try {
int sales = Integer.parseInt(line);
if (sales >= 0) {
return sales;
}
} catch (NumberFormatException e) {
// fall through to the error message
}
System.out.print("Enter a whole number of 0 or more: ");
}
}
private static Console createConsole(int choice, String store, int sales) {
switch (choice) {
case 1: return new PS5(store, sales);
case 2: return new Xbox(store, sales);
default: return new NintendoSwitch(store, sales);
}
}
}
